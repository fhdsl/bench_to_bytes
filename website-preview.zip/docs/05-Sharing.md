# Public Data and Code Sharing and Reuse

The final "why computational skill are useful" theme that we'll explore is public data and code sharing and reuse




## Learning Objectives

This chapter will cover:

- {LO1}
- {LO2}
