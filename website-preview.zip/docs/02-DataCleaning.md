# Data cleaning

The first "why computational skill are useful" theme that we'll explore is data cleaning.




## Learning Objectives

This chapter will cover:

- {LO1}
- {LO2}
