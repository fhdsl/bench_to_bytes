# Data visualization

The second "why computational skill are useful" theme that we'll explore is data visualization




## Learning Objectives

This chapter will cover:

- {LO1}
- {LO2}
